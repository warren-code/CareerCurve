const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },

  subscription: {
    tier: {
      type: String,
      enum: ['free', 'launch', 'accelerate', 'pinnacle'],
      default: 'free'
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'past_due', 'canceled'],
      default: 'inactive'
    },
    stripeCustomerId: {
      type: String,
      select: false
    },
    stripeSubscriptionId: {
      type: String,
      select: false
    },
    currentPeriodEnd: {
      type: Date,
      select: false
    }
  },

  usage: {
    resumeExports: {
      count: { type: Number, default: 0 },
      lastReset: { type: Date, default: Date.now }
    }
  }

}, { timestamps: true });

userSchema.pre('save', function(next) {
  if (this.isNew && this.subscription.tier === 'free') {
    this.subscription.status = 'active';
  }
  next();
});

module.exports = mongoose.model('User', userSchema);
