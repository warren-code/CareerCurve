const express = require('express');
const router = express.Router();
const { protect, checkTier } = require('../middleware/authMiddleware');
const {
  advancedSkillGapAnalysis,
  aiInterviewPrep,
  aiNetworkingGuidance,
  careerPathSimulation,
  aiMockInterview,
} = require('../controllers/featureController');

router.post('/advanced-skill-gap', protect, checkTier('accelerate'), advancedSkillGapAnalysis);
router.post('/ai-interview-prep', protect, checkTier('accelerate'), aiInterviewPrep);
router.post('/ai-networking-guidance', protect, checkTier('accelerate'), aiNetworkingGuidance);

router.post('/career-path-simulation', protect, checkTier('pinnacle'), careerPathSimulation);
router.post('/ai-mock-interview', protect, checkTier('pinnacle'), aiMockInterview);

module.exports = router;
