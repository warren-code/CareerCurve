const express = require('express');
const router = express.Router();
const { 
    getSubscriptionData, 
    createStripePortalSession,
    createStripeCheckoutSession
} = require('../controllers/subscriptionController');
const { protect } = require('../middleware/authMiddleware');

router.get('/status', protect, getSubscriptionData);
router.post('/create-portal-session', protect, createStripePortalSession);
router.post('/create-checkout-session', protect, createStripeCheckoutSession);

module.exports = router;
