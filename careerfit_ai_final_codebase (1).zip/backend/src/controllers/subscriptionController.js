const asyncHandler = require('express-async-handler');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const User = require('../models/userModel');

const getSubscriptionData = asyncHandler(async (req, res) => {
  if (!req.user || !req.user.subscription) {
    res.status(404);
    throw new Error('Subscription data not found for user');
  }
  res.status(200).json(req.user.subscription);
});

const createStripePortalSession = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id).select('+subscription.stripeCustomerId');

  if (!user || !user.subscription.stripeCustomerId) {
    res.status(400);
    throw new Error('Stripe customer ID not found for this user.');
  }

  const returnUrl = process.env.CLIENT_URL || 'http://localhost:3000/profile';

  const portalSession = await stripe.billingPortal.sessions.create({
    customer: user.subscription.stripeCustomerId,
    return_url: returnUrl,
  });

  res.status(200).json({ url: portalSession.url });
});

const createStripeCheckoutSession = asyncHandler(async (req, res) => {
  const { priceId, tier } = req.body;
  const user = await User.findById(req.user.id).select('+subscription.stripeCustomerId');

  if (!priceId || !tier) {
    res.status(400);
    throw new Error('Price ID and tier are required');
  }

  const priceIdToTierMap = {
    [process.env.STRIPE_LAUNCH_PRICE_ID]: 'launch',
    [process.env.STRIPE_ACCELERATE_PRICE_ID]: 'accelerate',
    [process.env.STRIPE_PINNACLE_PRICE_ID]: 'pinnacle',
  };

  if (priceIdToTierMap[priceId] !== tier) {
      res.status(400);
      throw new Error('Invalid price ID and tier combination.');
  }

  let stripeCustomerId = user.subscription.stripeCustomerId;

  if (!stripeCustomerId) {
    const customer = await stripe.customers.create({
      email: user.email,
      name: user.name,
      metadata: {
        userId: user.id,
      },
    });
    stripeCustomerId = customer.id;
    user.subscription.stripeCustomerId = stripeCustomerId;
    await user.save();
  }

  const successUrl = `${process.env.CLIENT_URL || 'http://localhost:3000'}/index.html?payment_success=true`;
  const cancelUrl = `${process.env.CLIENT_URL || 'http://localhost:3000'}/pricing.html?payment_canceled=true`;

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'subscription',
    customer: stripeCustomerId,
    line_items: [{
      price: priceId,
      quantity: 1,
    }],
    success_url: successUrl,
    cancel_url: cancelUrl,
    client_reference_id: user.id,
    subscription_data: {
        metadata: {
            tier: tier
        }
    }
  });

  res.status(200).json({ url: session.url });
});

const handleStripeWebhook = async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let event;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error(`Webhook signature verification failed: ${err.message}`);
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }

  try {
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;

      if (session.payment_status === 'paid') {
        const userId = session.client_reference_id;
        const stripeSubscriptionId = session.subscription;
        const stripeCustomerId = session.customer;

        const subscription = await stripe.subscriptions.retrieve(stripeSubscriptionId);

        const user = await User.findById(userId);
        if (user) {
          user.subscription.tier = subscription.metadata.tier;
          user.subscription.status = 'active';
          user.subscription.stripeSubscriptionId = stripeSubscriptionId;
          user.subscription.stripeCustomerId = stripeCustomerId;
          user.subscription.currentPeriodEnd = new Date(subscription.current_period_end * 1000);
          await user.save();
        } else {
          console.error(`Webhook 'checkout.session.completed': User not found with ID: ${userId}`);
        }
      }
    }
    res.status(200).json({ received: true });
  } catch (err) {
    console.error(`Webhook handler error: ${err.message}`);
    res.status(500).json({ error: 'Internal server error in webhook handler.' });
  }
};


module.exports = {
  getSubscriptionData,
  createStripePortalSession,
  createStripeCheckoutSession,
  handleStripeWebhook,
};
