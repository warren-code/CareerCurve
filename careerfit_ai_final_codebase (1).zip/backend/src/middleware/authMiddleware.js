const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const User = require('../models/userModel');

const protect = asyncHandler(async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');

      if (!req.user) {
        res.status(401);
        throw new Error('Not authorized, user not found');
      }

      next();
    } catch (error) {
      console.error(error);
      res.status(401);
      throw new Error('Not authorized, token failed');
    }
  }

  if (!token) {
    res.status(401);
    throw new Error('Not authorized, no token');
  }
});

const TIER_HIERARCHY = {
  free: 0,
  launch: 1,
  accelerate: 2,
  pinnacle: 3,
};

const checkTier = (requiredTier) => asyncHandler(async (req, res, next) => {
  const userTier = req.user.subscription.tier;

  if (req.user.subscription.status !== 'active') {
    res.status(403);
    throw new Error('Subscription is not active.');
  }

  if (TIER_HIERARCHY[userTier] >= TIER_HIERARCHY[requiredTier]) {
    next();
  } else {
    res.status(403);
    throw new Error(`Access denied. This feature requires a '${requiredTier}' plan or higher.`);
  }
});

const checkResumeExportUsage = asyncHandler(async (req, res, next) => {
    const TIER_LIMITS = { 
        free: 3, 
        launch: Infinity, 
        accelerate: Infinity, 
        pinnacle: Infinity 
    };
    const user = req.user;
    const tierLimit = TIER_LIMITS[user.subscription.tier];

    if (tierLimit === undefined) {
        res.status(403);
        throw new Error('Invalid subscription tier for usage check.');
    }
    
    if (tierLimit === Infinity) {
        return next();
    }

    const oneMonthAgo = new Date();
    oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
    if (user.usage.resumeExports.lastReset < oneMonthAgo) {
        user.usage.resumeExports.count = 0;
        user.usage.resumeExports.lastReset = new Date();
        await user.save({ session: req.session });
    }

    if (user.usage.resumeExports.count < tierLimit) {
        next();
    } else {
        res.status(429);
        throw new Error(`You have reached your monthly limit of ${tierLimit} resume exports. Please upgrade for unlimited exports.`);
    }
});

const incrementResumeExportUsage = asyncHandler(async (req, res, next) => {
    req.user.usage.resumeExports.count += 1;
    await req.user.save({ session: req.session });
    next();
});


module.exports = { protect, checkTier, checkResumeExportUsage, incrementResumeExportUsage };
