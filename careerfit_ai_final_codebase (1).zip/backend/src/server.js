const express = require('express');
const dotenv = require('dotenv');
const { handleStripeWebhook } = require('./controllers/subscriptionController');
const subscriptionRoutes = require('./routes/subscriptionRoutes');
const featureRoutes = require('./routes/featureRoutes');

dotenv.config();

const app = express();

app.post('/api/subscriptions/webhook', express.raw({ type: 'application/json' }), handleStripeWebhook);

app.use(express.json());

app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/features', featureRoutes);

const errorHandler = (err, req, res, next) => {
  const statusCode = res.statusCode ? res.statusCode : 500;
  res.status(statusCode);
  res.json({
    message: err.message,
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
};
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

app.listen(
  PORT,
  console.log(
    `Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`
  )
);

module.exports = app;
