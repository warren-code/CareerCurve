# CareerFit AI

CareerFit AI is an intelligent career development platform designed to empower users with AI-driven tools for resume building, job matching, skill analysis, and interview preparation. The application features a tiered subscription model to provide scalable access to its features, from essential tools for getting started to advanced simulations for career acceleration.

---

## **Features & Subscription Tiers**

The platform offers a range of features tailored to different career stages, organized into four distinct tiers.

| Feature | Free Trial | Launch | Accelerate | Pinnacle |
| :--- | :---: | :---: | :---: | :---: |
| **Core Tools** | | | | |
| AI CV & Resume Builder | 3 per month | ✅ Unlimited | ✅ Unlimited | ✅ Unlimited |
| AI Cover Letter Generator | 3 per month | ✅ Unlimited | ✅ Unlimited | ✅ Unlimited |
| Basic Skill Gap Analysis | ❌ | ✅ | ✅ | ✅ |
| Personalized Job Matching | Basic | Standard | Advanced | Executive-Level |
| **Accelerate Features** | | | | |
| Advanced Skill Gap Analysis | ❌ | ❌ | ✅ | ✅ |
| AI Interview Preparation (Q&A) | ❌ | ❌ | ✅ | ✅ |
| AI-Powered Networking Guidance | ❌ | ❌ | Basic | Advanced |
| **Pinnacle Features** | | | | |
| Career Path Simulation | ❌ | ❌ | ❌ | ✅ |
| AI Mock Interview (Video) | ❌ | ❌ | ❌ | ✅ |
| **Billing** | | | | |
| Subscription Management Portal | N/A | ✅ | ✅ | ✅ |

---

## **Technical Stack**

*   **Backend:** Node.js, Express.js
*   **Database:** MongoDB with Mongoose ODM
*   **Payments:** Stripe for subscription management and payment processing
*   **Authentication:** JSON Web Tokens (JWT)
*   **Frontend:** Vanilla HTML, CSS, and JavaScript with TailwindCSS

---

## **Project Structure**

The project is organized into a standard structure with separate `backend` and frontend files.

