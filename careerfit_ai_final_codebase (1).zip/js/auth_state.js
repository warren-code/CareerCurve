const AUTH_KEY = 'careerfit_auth_state';

const defaultState = {
    email: 'demo-user@careerfit.ai',
    tier: 'free',
    token: 'mock-jwt-token-for-demo-purposes'
};

export function getAuthState() {
    try {
        const storedState = localStorage.getItem(AUTH_KEY);
        if (storedState) {
            return JSON.parse(storedState);
        }
    } catch (error) {
        console.error('Error reading auth state from localStorage:', error);
    }
    setAuthState(defaultState);
    return defaultState;
}

export function setAuthState(newState) {
    try {
        localStorage.setItem(AUTH_KEY, JSON.stringify(newState));
    } catch (error) {
        console.error('Error saving auth state to localStorage:', error);
    }
}
