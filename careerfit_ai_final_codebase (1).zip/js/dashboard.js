import { getAuthState } from './auth_state.js';
import { featuresByTier, TIER_HIERARCHY } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
    updateDashboardUI();
    setupFeatureButtons();
    document.getElementById('download-zip-btn').addEventListener('click', createAndDownloadZip);
    lucide.createIcons();
});

function updateDashboardUI() {
    const { email, tier } = getAuthState();

    document.getElementById('user-email').textContent = email;
    document.getElementById('user-tier').textContent = tier;
    
    const tierFeatures = featuresByTier[tier].features;

    document.getElementById('resume-exports').textContent = `(${tierFeatures['AI CV & Resume Builder']})`;
    document.getElementById('cover-letter-exports').textContent = `(${tierFeatures['AI Cover Letter Generator']})`;
    document.getElementById('job-matching-level').textContent = `(${tierFeatures['Personalized Job Matching']})`;

    toggleFeatureCard('basic-skill-gap-card', tierFeatures['Basic Skill Gap Analysis'] !== 'Not Included');
    toggleFeatureCard('advanced-skill-gap-card', tierFeatures['Advanced Skill Gap Analysis'] !== 'Not Included');
    toggleFeatureCard('ai-interview-prep-card', tierFeatures['AI Interview Preparation (Q&A)'] !== 'Not Included');
    toggleFeatureCard('ai-networking-guidance-card', tierFeatures['AI-Powered Networking Guidance'] !== 'Not Included');
    toggleFeatureCard('career-path-simulation-card', tierFeatures['Career Path Simulation'] !== 'Not Included');
    toggleFeatureCard('ai-mock-interview-card', tierFeatures['AI Mock Interview (Video)'] !== 'Not Included');
    
    const networkingLevelEl = document.getElementById('networking-level');
    if (tierFeatures['AI-Powered Networking Guidance'] !== 'Not Included') {
        networkingLevelEl.textContent = `(${tierFeatures['AI-Powered Networking Guidance']})`;
        networkingLevelEl.parentElement.style.display = 'block';
    } else {
        networkingLevelEl.parentElement.style.display = 'none';
    }
}

function toggleFeatureCard(cardId, isVisible) {
    const card = document.getElementById(cardId);
    if (card) {
        card.style.display = isVisible ? 'flex' : 'none';
    }
}

function setupFeatureButtons() {
    document.getElementById('advanced-skill-gap-btn')?.addEventListener('click', () => callFeatureApi('Advanced Skill Gap Analysis', '/api/features/advanced-skill-gap'));
    document.getElementById('ai-interview-prep-btn')?.addEventListener('click', () => callFeatureApi('AI Interview Prep', '/api/features/ai-interview-prep'));
    document.getElementById('ai-networking-guidance-btn')?.addEventListener('click', () => callFeatureApi('AI Networking Guidance', '/api/features/ai-networking-guidance'));
    document.getElementById('career-path-simulation-btn')?.addEventListener('click', () => callFeatureApi('Career Path Simulation', '/api/features/career-path-simulation'));
    document.getElementById('ai-mock-interview-btn')?.addEventListener('click', () => callFeatureApi('AI Mock Interview (Video)', '/api/features/ai-mock-interview'));
}

async function callFeatureApi(featureName, endpoint) {
    const { tier } = getAuthState();
    const userTierLevel = TIER_HIERARCHY[tier];
    let requiredTierName = 'free';
    let requiredTierLevel = 0;

    if (endpoint.includes('advanced-skill-gap') || endpoint.includes('ai-interview-prep') || endpoint.includes('ai-networking-guidance')) {
        requiredTierName = 'accelerate';
        requiredTierLevel = TIER_HIERARCHY.accelerate;
    } else if (endpoint.includes('career-path-simulation') || endpoint.includes('ai-mock-interview')) {
        requiredTierName = 'pinnacle';
        requiredTierLevel = TIER_HIERARCHY.pinnacle;
    }
    
    showApiResponse({ message: `Simulating access to ${featureName}...` });

    if (userTierLevel >= requiredTierLevel) {
        const mockSuccessData = {
            success: true,
            message: `${featureName} accessed successfully.`,
            data: { details: `This is mock data for the ${featureName} feature, available to the ${tier} tier.` }
        };
        if (featureName === 'AI Networking Guidance') {
            mockSuccessData.data.guidance = featuresByTier[tier].features['AI-Powered Networking Guidance'] + ' guidance';
        }
        setTimeout(() => showApiResponse(mockSuccessData, `Success: ${featureName}`), 500);
    } else {
        const mockErrorData = {
            error: `Access Denied`,
            message: `Your current tier ('${tier}') does not have access. This feature requires a '${requiredTierName}' plan or higher.`
        };
        setTimeout(() => showApiResponse(mockErrorData, 'Error: Access Denied'), 500);
    }
}

function showApiResponse(data, title = 'API Response') {
    const responseContainer = document.getElementById('api-response');
    const responsePre = responseContainer.querySelector('pre');
    const responseTitle = responseContainer.querySelector('h3');
    
    responseTitle.textContent = title;
    responsePre.textContent = JSON.stringify(data, null, 2);
    responseContainer.classList.remove('hidden');
}

async function createAndDownloadZip() {
    const zip = new JSZip();
    const fileList = [
        'index.html',
        'pricing.html',
        'README.md',
        'css/style.css',
        'js/auth_state.js',
        'js/data.js',
        'js/dashboard.js',
        'js/pricing.js',
        'backend/package.json',
        'backend/.env.example',
        'backend/src/server.js',
        'backend/src/controllers/featureController.js',
        'backend/src/controllers/subscriptionController.js',
        'backend/src/middleware/authMiddleware.js',
        'backend/src/models/userModel.js',
        'backend/src/routes/featureRoutes.js',
        'backend/src/routes/subscriptionRoutes.js'
    ];

    const downloadBtn = document.getElementById('download-zip-btn');
    const originalContent = downloadBtn.innerHTML;
    downloadBtn.disabled = true;
    downloadBtn.innerHTML = `<i data-lucide="loader-2" class="w-4 h-4 mr-2 animate-spin"></i><span>Packaging...</span>`;
    lucide.createIcons();

    const fetchPromises = fileList.map(async (filePath) => {
        try {
            const response = await fetch(filePath);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            const content = await response.text();
            zip.file(filePath, content);
        } catch (error) {
            console.error(`Failed to fetch ${filePath}:`, error);
            zip.file(`ERROR_FETCHING_${filePath.replace(/\//g, '_')}.txt`, `Could not fetch ${filePath}.\nError: ${error.message}`);
        }
    });

    await Promise.all(fetchPromises);

    zip.generateAsync({ type: "blob" })
        .then(function(content) {
            saveAs(content, "careerfit_ai_final_codebase.zip");
            downloadBtn.innerHTML = originalContent;
            downloadBtn.disabled = false;
            lucide.createIcons();
        });
}
