import { getAuthState, setAuthState } from './auth_state.js';
import { featuresByTier } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
    renderPricingCards();
    lucide.createIcons();
});

function renderPricingCards() {
    const container = document.getElementById('pricing-container');
    const { tier: currentTier } = getAuthState();
    
    const cardsHtml = Object.values(featuresByTier).map(tier => createPricingCard(tier, currentTier)).join('');
    
    container.innerHTML = `<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">${cardsHtml}</div>`;
    
    addCardEventListeners();
}

function createPricingCard(tier, currentTier) {
    const isCurrent = tier.id === currentTier;
    const isRecommended = tier.recommended;

    const featureList = Object.entries(tier.features).map(([name, detail]) => {
        const isIncluded = detail !== 'Not Included';
        const icon = isIncluded ? 'check-circle-2' : 'x-circle';
        const colorClass = isIncluded ? 'included' : 'not-included';
        return `
            <li class="${colorClass}">
                <i data-lucide="${icon}"></i>
                <span>${name}${isIncluded && detail !== 'Available' ? ` (${detail})` : ''}</span>
            </li>
        `;
    }).join('');

    let buttonHtml;
    if (isCurrent) {
        buttonHtml = `<button disabled class="pricing-button current">Current Plan</button>`;
    } else {
        buttonHtml = `<button data-tier-id="${tier.id}" class="pricing-button ${isRecommended ? 'primary' : 'secondary'}">Select Plan</button>`;
    }

    return `
        <div class="pricing-card ${isRecommended ? 'recommended' : ''}">
            ${isRecommended ? '<div class="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2 bg-cyan-500 text-white text-sm font-semibold px-4 py-1 rounded-full">Most Popular</div>' : ''}
            <h3 class="text-2xl font-bold text-white text-center">${tier.name}</h3>
            <div class="text-center my-4">
                <span class="text-5xl font-extrabold text-white">${tier.price}</span>
                <span class="text-gray-400">${tier.priceDetail}</span>
            </div>
            <ul class="my-6 space-y-3 text-sm">
                ${featureList}
            </ul>
            ${buttonHtml}
        </div>
    `;
}

function addCardEventListeners() {
    document.querySelectorAll('.pricing-button[data-tier-id]').forEach(button => {
        button.addEventListener('click', (e) => {
            const tierId = e.target.dataset.tierId;
            const currentState = getAuthState();
            setAuthState({ ...currentState, tier: tierId });
            window.location.href = 'index.html';
        });
    });
}
